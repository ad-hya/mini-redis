from mini_redis.server import serve

if __name__ == "__main__":
    serve(port=6380)
